#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
export ANDROID_HOME
export ANDROID_SDK_ROOT="$ANDROID_HOME"
GRADLE_BIN="${GRADLE_BIN:-gradle}"
cd "$ROOT"
"$GRADLE_BIN" --no-daemon clean assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$APK" ]]; then
  echo "ERRO: APK não foi gerado em $APK" >&2
  exit 2
fi
sha256sum "$APK" | tee "$ROOT/app/build/outputs/apk/debug/app-debug.apk.sha256"
echo "APK: $APK"
