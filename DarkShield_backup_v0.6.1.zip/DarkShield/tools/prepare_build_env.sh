#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
export ANDROID_HOME
export ANDROID_SDK_ROOT="$ANDROID_HOME"
SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
if [[ ! -x "$SDKMANAGER" ]]; then
  echo "Android command-line tools não encontrados em: $SDKMANAGER"
  echo "Instale o Android SDK Command-line Tools e reexecute este script." >&2
  exit 3
fi
yes | "$SDKMANAGER" --licenses >/dev/null || true
"$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0"
echo "Ambiente Android preparado em $ANDROID_HOME"
