# DarkShield — Android Security Auditor

Versão: 0.2.0

## O que esta versão faz
- Enumera aplicativos visíveis ao PackageManager.
- Analisa permissões sensíveis e recursos de alto impacto.
- Identifica serviços de acessibilidade declarados e ativos.
- Identifica administradores do dispositivo ativos.
- Detecta acesso a notificações ativo.
- Verifica estado de Opções do Desenvolvedor e ADB.
- Mostra origem de instalação quando o Android fornece essa informação.
- Calcula SHA-256 do certificado de assinatura dos aplicativos.
- Usa heurísticas para sinalizar possíveis aplicativos de acesso remoto.
- Calcula uma pontuação heurística de risco e não remove nada automaticamente.

## O que ele NÃO afirma
Nenhum aplicativo comum pode provar que o telefone está 100% livre de invasão. O Android impõe limites de isolamento entre aplicativos. Um alerta é um indicador para investigação, não uma prova de malware.

## ADB / Modo Desenvolvedor
O modo desenvolvedor sozinho não dá ao DarkShield privilégios de root. O fluxo avançado pode usar ADB a partir de um computador autorizado para coletar informações adicionais do sistema.

Exemplo de coleta:
```bash
adb devices
adb shell getprop > darkshield_getprop.txt
adb shell settings list global > darkshield_settings_global.txt
adb shell settings list secure > darkshield_settings_secure.txt
adb shell pm list packages -f > darkshield_packages.txt
adb shell dumpsys package > darkshield_dumpsys_package.txt
adb shell dumpsys device_policy > darkshield_device_policy.txt
adb shell dumpsys accessibility > darkshield_accessibility.txt
adb shell dumpsys notification > darkshield_notification.txt
```

## Build
O projeto usa Android Gradle Plugin e target SDK 35. Esta entrega não inclui um Gradle wrapper nem SDK Android no ambiente de criação, portanto o APK precisa ser compilado em uma máquina com Android Studio/SDK instalado.

Abra a pasta `DarkShield` no Android Studio e execute `Build > Build APK(s)`.

## Próxima evolução
A próxima fase deve adicionar importação do relatório ADB, tela por aplicativo com explicação dos indicadores, lista de IOCs/hashes assinados, exportação JSON e fluxo guiado para revogação/desinstalação feita pelo usuário.

## Compilação
Veja `BUILD_ENV.md`. O projeto inclui Docker e GitHub Actions para gerar o APK.
